
<?php include("cabecalho1.php"); ?>

<?php include("menufalso.php"); ?>
<div id="fundo">
<br />
<br />
<br />

<!-- Start Formoid form-->
<link rel="stylesheet" href="form-atualização-senha_files/formoid1/formoid-metro-cyan.css" type="text/css" />
<script type="text/javascript" src="form-atualização-senha_files/formoid1/jquery.min.js"></script>

<form class="formoid-metro-cyan" style="background-color:#FFFFFF;font-size:14px;font-family:'Open Sans','Helvetica Neue','Helvetica',Arial,Verdana,sans-serif;color:#666666;max-width:480px;min-width:150px" method="post" action="query/confirma-atua-senha.php"><div class="title"><h2>Atualização de Senha</h2></div>
	
 <div class="element-email"><label class="title">Email</label><input class="large" type="email" name="email" value="" /></div>

<div class="submit"><input type="submit" value="Enviar"/></div></form><p class="frmd"><a href="http://formoid.com/v29.php">online forms</a> Formoid.com 2.9</p><script type="text/javascript" src="form-atualização-senha_files/formoid1/formoid-metro-cyan.js"></script>
<!-- Stop Formoid form-->
</div>
<?php include("rodape.php"); ?>

