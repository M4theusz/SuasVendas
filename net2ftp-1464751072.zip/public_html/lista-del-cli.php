﻿<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/formatacao.css">
<title>Documento sem título</title>
</head>

<body>


		<form name="f_excluir" method="post" action="listadeclientes.php">

				<table cellspacing="30"  cellpadding="1000" border="1" width="1300px" id="table">
    
  					  <tr>
    					
                        <td><b>Nome</b></td> 
        				<td><b>Cpf/Cnpj</b></td> 
       					<td><b>Fantasia</b></td>
						<td><b>Telefone</b></td> 
        				<td><b>Email</b></td>
        				<td><b>APAGAR</b></td>
    				
                     </tr>
                     
                     
   <?php 
	include("conexao.php");
	
	$sql= "SELECT * FROM clientes ";
	$res=mysqli_query($conn,$sql);
	
	while($linha=mysqli_fetch_assoc($res))
	
	{
	echo "<tr>";
		
	echo "<td>".$linha['nome']."</td>";
	echo "<td>".$linha['cpf_cnpj']."</td>";
	echo "<td>".$linha['nome_fantasia']."</td>";
	echo "<td>".$linha['telefone']."</td>";
	echo "<td>".$linha['email']."</td>";
	if(strpos($_SESSION['acesso'],'d',0))
	{
	echo "<td><a href='apagarcli.php?id=".$linha['cpf_cnpj']."'><img src='img/botao.png' width='30'></a></td>";
	}
	echo "</tr>";
		
		
		
	}
	
	?>
    
    
    
    
   </table>
   <br />
   
   


   </form>



</body>
</html>
</center></center>
</div>