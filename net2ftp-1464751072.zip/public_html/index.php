﻿
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/login.css" />
<title>Login</title>
</head>
<body onload="document.forms['formaction'].elements['user'].focus();">
<table style="width: 100%; height: 100%;">
  <tr>
     <td style="text-align: center; vertical-align: middle;">
        

<div class="login_wrap">
    <div class="logo">
    <img src="img/LogoNova.svg" widht="35" height="35" /> 
        
    </div>
    <div class="vform">
        
        
        <form  id='formaction' action="login.php" method="post" onsubmit="document.getElementById('tsubmit').style.display='none'; document.getElementById('loadeux').style.display='';">
            <fieldset class="float">
                
                <label>Usuario</label>
                <input type="text"  name="usuario" class="usertext"><br>
                
                <label class="clear">Senha</label>
                <input type="password" name="senha" class="usertext"><br>
                
                <label class="clear">Permissao</label>
                <input type="text"  name="acesso" class="usertext"><br>
                
                
                <label class="clear"></label>
				<input id='tsubmit' class="cute_button" type="submit" style="clear:none;" value="Login" onclick="document.getElementById('tsubmit').style.display='none'; document.getElementById('loadeux').style.display=''; document.getElementById('formaction').submit();">
										<img id='loadeux' src="http://admin.myvirtualpaper.com/images/loader.gif" width="25" height="25" style="display:none;position:relative;top: 5px; left: 70px">
            </fieldset>
                    
                    
              
                    
                  <div class="clear">
                 </div>
                
                
                <div style="text-align: center;">
                    <label>
                    <input type="checkbox" name="doRememberUsername"> Lembrar Senha |
                    </label>
                    
                    <label>
                    <a href="form-atualizacao-senha.php">Esqueceu sua Senha?</a>
                    </label>
                        
                <br />
                
                <a href="cadastro.php"><font size="2" color="#777"><u>Cadastro</u></font></a>
                   </div>      
                
        </form>
                    <!--<div class="get_started"><a href="http://america.myvirtualpaper.com/Online_Publishing/trial/">Don't have a login? Get Started!</a></div>-->
    </div>
		<div id="me_box">
		    		    		 </div>
                    
</div>

     </td>
  </tr>
</table>



<div class="login_body" style="background-color:;">
<center>
<div id="me_box">
</div>

</center>

</div>

</body>
</html>