﻿<?php include("autenticacao.php"); ?>
<?php include("cabecalho1.php");
header('refresh:3; http:form-atualizacao-senha.php'); ?>

<?php include("menu.php"); ?>

<div id="fundo">
<h1>
<center>
Email não Encontrado!!
</center>
</h1>
</div>
<?php include("rodape.php"); 



?>	