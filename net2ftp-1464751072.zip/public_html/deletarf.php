<?php $form_path='deletarf_files/formoid1/form.php'; require_once $form_path; ?><!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Deletar Fornecedores - Formoid bootstrap forms</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body class="blurBg-false" style="background-color:#EBEBEB">

{{Formoid}}

</body>
</html>
