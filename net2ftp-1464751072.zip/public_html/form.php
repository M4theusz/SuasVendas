<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>Cadastro de Clientes - Formoid jquery form validation</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>




<!-- Start Formoid form-->
<link rel="stylesheet" href="form_files/formoid1/formoid-metro-blue.css" type="text/css" />
<script type="text/javascript" src="form_files/formoid1/jquery.min.js"></script>
<form class="formoid-metro-blue" style="background-color:#FFFFFF;font-size:14px;font-family:'Open Sans','Helvetica Neue','Helvetica',Arial,Verdana,sans-serif;color:#666666;max-width:480px;min-width:150px" method="post" action="query/cadcli.php"><div class="title"><h2>Cadastro de Clientes</h2></div>
	
    
    <div class="element-input"><label class="title">Nome do Cliente</label><input class="large" type="text" name="nome" /></div>
	
    <div class="element-phone"><label class="title">CPF/CNPJ</label><input class="large" type="tel"  name="cpfcpnj"  value=""/></div>
	
    <div class="element-email"><label class="title">Email</label><input class="large" type="email" name="email" value="" /></div>
	
    <div class="element-phone"><label class="title">Telefone</label><input class="large" type="tel" pattern="[+]?[\.\s\-\(\)\*\#0-9]{3,}" maxlength="24" name="telefone"  value=""/></div>
	
    <div class="element-input"><label class="title">Nome Fantasia</label><input class="large" type="text" name="nome_fantasia" /></div>






<div class="submit"><input type="submit" value="Enviar"/></div>
</form><p class="frmd"><a href="http://formoid.com/v29.php">jquery form validation</a> Formoid.com 2.9</p><script type="text/javascript" src="form_files/formoid1/formoid-metro-blue.js"></script>
<!-- Stop Formoid form-->



</body>
</html>
