﻿
<html>
<head>

<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<link href='https://fonts.googleapis.com/css?family=Alegreya:400,700,400italic' rel='stylesheet' type='text/css'>

<link rel="stylesheet" type="text/css" href="css/edimenu.css">

<link rel="stylesheet" type="text/css" href="css/formatacao.css">

<link rel="shortcut icon" href="img/favicon.jpg" type="image/x-icon"/>

<link rel="stylesheet" href="css/ediform.css" />

<link href='http://fonts.googleapis.com/css?family=Engagement' rel='stylesheet' type='text/css'>


<title> SuasVendas.com</title>

</head>
<body>
<div class="uma-div">


<div id="topo">
<img src="img/LogoNova.svg" width="1100" height="135">
</div>
