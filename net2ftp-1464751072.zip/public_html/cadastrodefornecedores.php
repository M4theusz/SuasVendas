﻿<?php include("autenticacao.php"); ?>
<?php include("cabecalho1.php"); ?>



<?php include("menu.php"); ?>
<div id="fundo">
<br>
<?php include("conexao.php");?>
<?php include("query/cadforn.php");?>
<br>
<br>
<?php include("cadastroF.php");?>
</div>
<?php include("rodape.php"); ?>	