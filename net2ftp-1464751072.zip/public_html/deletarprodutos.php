﻿<?php include("cabecalho.php"); ?>
<?php include("menu.php"); ?>
<?php include("conexao.php");?>
<?php include("delprod.php");?>

<div id="conteudo">
<div id="conteudotitulo"><br > 
Deletar Produtos
</div>
<br > 
<center>

<form id="contactform" class="rounded" method="post" action="deletarprodutos.php">
				
				<br>
				<br>
				<label ="cod">Digite o Codigo do Produto:</label>
               
		<input type="text" name="cod" /><br>
			
            <input type="submit" class="button"value="Enviar" /> 
		</form>
        </center>
</div>

<?php include("rodape.php"); ?>	