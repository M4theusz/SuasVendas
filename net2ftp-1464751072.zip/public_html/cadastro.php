﻿
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/login.css" />
<title>Login</title>
</head>
<body onload="document.forms['formaction'].elements['user'].focus();">
<table style="width: 100%; height: 100%;">
  <tr>
     <td style="text-align: center; vertical-align: middle;">
        

<div class="login_wrap">
    <div class="logo">
    <img src="img/LogoNova.svg" widht="35" height="35" /> 
        
    </div>
    <div class="vform">
        
        
        <form  id='formaction' action="registro.php" method="post" onsubmit="document.getElementById('tsubmit').style.display='none'; document.getElementById('loadeux').style.display='';">
            <fieldset class="float">
                <label>Usuario</label>
                <input type="text"  name="usuario" class="usertext"><br>
                
                
                <label class="clear">Senha</label>
                <input type="password" name="senha" class="usertext"><br>
                
                
                 <label class="clear">Permissão</label>
                <input type="text" name="acesso" placeholder="Comece com a letra M " class="usertext"><br>
                
                 <label class="clear">Email</label>
                <input type="email" name="email" class="usertext"><br>
                
                
                <label class="clear"></label>
				<input id='tsubmit' class="cute_button" type="submit" style="clear:none;" value="Cadastrar" onclick="document.getElementById('tsubmit').style.display='none'; document.getElementById('loadeux').style.display=''; document.getElementById('formaction').submit();">
										<img id='loadeux' src="http://admin.myvirtualpaper.com/images/loader.gif" width="25" height="25" style="display:none;position:relative;top: 5px; left: 70px">
            </fieldset>
                    
                    Tipo de Permissão: u,i,d,ui,ud,id,idu. (i=insert. u=update. d=delete).
              
                    
                 
		    		    		 </div>
                    
</div>

     </td>
  </tr>
</table>



<div class="login_body" style="background-color:;">
<center>
<div id="me_box">
</div>

</center>

</div>

</body>
</html>