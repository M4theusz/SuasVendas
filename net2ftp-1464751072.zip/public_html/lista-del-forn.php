﻿<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/formatacao.css">
<title>Documento sem título</title>
</head>

<body>


		<form name="f_excluir" method="post" action="listadefornecedores.php">
 
				<table cellspacing="20"  cellpadding="40px" border="1" width="900" id="table">
    
  					  <tr>
    					
                        <td><b>Nome da Empresa</b></td> 
        				<td><b>Cnpj</b></td> 
       					<td><b>E-mail</b></td>
						<td><b>Telefone</b></td> 
        				<td><b>Cod de Produto da Emp</b></td>
        				<td><b>APAGAR</b></td>
    				
                     </tr>
                     
   
    <?php 
	
	include("conexao.php");
	
	$sql= "SELECT * FROM fornecedores ";
	$res=mysqli_query($conn,$sql);
	
	while($linha=mysqli_fetch_assoc($res))
	{
	echo "<tr>";
		
	echo "<td>".$linha['nomedaempresa']."</td>";
	echo "<td>".$linha['cnpj']."</td>";
	echo "<td>".$linha['email']."</td>";
	echo "<td>".$linha['telefone']."</td>";
	echo "<td>".$linha['cod_prod_empresa']."</td>";
	
	 if(strpos($_SESSION['acesso'],'d',0))
	{
		echo "<td><a href='apagarforn.php?id=".$linha['cnpj']."'><img src='img/botao.png' width='30'></a></td>";
	}
	echo "</tr>";
		
		
		
	}
	
	?>
    
    
    
    
   </table>
   <br />
   
   


   </form>



</body>
</html>
</center></center>
</div>
