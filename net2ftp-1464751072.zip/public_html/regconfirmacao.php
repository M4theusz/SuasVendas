﻿<?php include("cabecalho1.php");
header('refresh:3; http:index.php'); ?>

<?php include("menufalso.php"); ?>

<div id="fundo">
<h1>
<center>
Cadastrado com Sucesso!!
</center>
</h1>
</div>
<?php include("rodape.php"); 



?>	