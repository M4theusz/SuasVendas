﻿<?php
if($_POST){
$fornecedor = $_POST['cnpj'];
$selecao = mysqli_query($conn,"DELETE  FROM fornecedores WHERE cnpj=$fornecedor");

}
?>