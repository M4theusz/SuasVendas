﻿<?php

 include 'conexao.php';
 
 //função de redirecionamento HEADER
 //header( 'HTTP/1.1 301 Moved Permanently');
// header( 'Location: index.php ');



if($_POST)
{ 

$nome = $_POST['usuario'];
$senha = $_POST['senha'];
$email= $_POST['email'];
$acesso= $_POST['acesso'];

$query = "INSERT INTO cadastro(";
$query = $query . "usuario,";
$query = $query . "senha,";
$query = $query . "email,";
$query = $query . "acesso)";


$query = $query . "VALUES(";
$query = $query . "'$nome',";
$query = $query . "MD5('$senha'),";
$query = $query . "'$email',";
$query = $query . "'$acesso')";

$res = mysqli_query($conn,$query) or die (mysql_error());

}
if($res)
{
header( 'Location: regconfirmacao.php ');
}
?>


