﻿<?php include("cabecalho.php"); ?>
<?php include("menu.php"); ?>



<div id="conteudo">

<div id="titulo">
<br>
Fornecedores
</div>

<br>
<br>
<br>

&nbsp;&nbsp;&nbsp;&nbsp;<a href="cadastrodefornecedores.php"><b>*</b>Cadastro de fornecedores</a>
<br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="listadefornecedores.php"><b>*</b>Lista de Fornecedores Cadastrados</a>
<br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="deletarfornecedores.php"><b>*</b>Apagar Fornecedores Cadastrados</a>
<br>

         

</div>


<?php include("rodape.php"); ?>	