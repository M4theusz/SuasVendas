﻿<?php
include("PHP/PHPMailerAutoload");

$Mailer = new PHPMailer();
//Define que sera usado SMTP
$Mailer -> IsSMTP();
//Aceitar caracteres especiais
$Mailer -> Charset = 'UTF-8';




//Configurações
$Mailer->SMTPAuth = true;
$Mailer->SMTPSecure = 'ssl';


//nome do servidor

$Mailer-> 'br160.hosgator.com.br';

//porta de saida

$Mailer-> '465';


//dados do email de saida
$Mailer->Username = 'admin@pontokc.com.br';
$Mailer->Password ='funildevendas'; 

//email remetente

$Mailer-> From='admin@pontokc.com.br';

//Nome do remetente
$Mailer->FromName = 'Celke';

//assunto da mensagem
$Mailer->Subjcts = "Titulo - recuperar senha";

//Conteudo da mensagem

$Mailer->Body = 'conteudo do emial';

//corpo da mensagemem texto

$Mailer->AltBody = 'conteudo do emial em texto';

//dESTINATARIO

$Mailer->AddAddress('celkadm@gmail.com');



if($Mailer->Send())
{
echo"Enviado com sucesso";	
}
else
{
echo"Falha no envio";	
}
