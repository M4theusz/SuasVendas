﻿<?php





define('FPDF_FONTPATH', 'font/');
require('fpdf/fpdf.php');
$pdf = new FPDF('P','cm','A4');
$pdf->Open();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);


if($_POST)
{
$nome= $_POST['nome'];
$empresa= $_POST['empresa'];
$nome= $_POST['nome'];


$sql="SELECT 
	  FROM clientes,fornecedores,produto 
	  WHERE clientes.nome = $nome  ,fornecedores.nomedaempresa = $empresa, fornecedores.cnpj = produto.cod_prod_empresa";
	 

$conect = mysql_connect("localhost","root","root");
if(!$conect) die ("<h1> Falha na coneção</h1>");

$db = mysql_select_db("representante_comercial");
$exe= mysql_query($sql) or die (mysql_error());
$palavra ="Relatorio de Pedidos";
$pdf->Cell(20,1,$palavra,0,1,'C');


while($resultado = mysql_fetch_array($exe))
{
$pdf->Cell(2,1,$resultado['$nome'],0,1,'L');
$pdf->Cell(3,1,$resultado['$empresa'],1,0,'L');
$pdf->Cell(5,1,$resultado['produto'],1,1,'L');
}


$pdf->Output();
}
?>
