﻿<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sem título</title>
</head>

<body>


		<form name="f_excluir" method="post" action="listadefornecedores.php">

				<table cellspacing="20"  cellpadding="90px" border="1" width="900"">
    
  					  <tr>
    					
                        <td><b>Nome da Empresa</b></td> 
        				<td><b>Cnpj</b></td> 
       					<td><b>E-mail</b></td>
						<td><b>Telefone</b></td> 
        				<td><b>Codigo de Produto da Empresa</b></td>
        				<td><b>SELECIONAR</b></td>
    				
                     </tr>
    
    <?php 
	include("conexao.php");
	
	
	if(isset($_POST['sel']))
	
	{
		foreach($_POST['sel']as $codigo)
		{
		
		$sql="DELETE FROM fornecedores WHERE cnpj = $codigo";
		$res = mysqli_query($conn,$sql);		
		} 

	}else
	{
	
	}

	
		
		
		
	
	
	
	$sql= "SELECT * FROM fornecedores ";
	$res=mysqli_query($conn,$sql);
	
	while($vreg=mysqli_fetch_row($res))
	{
		$vnome= $vreg[0];
		$vcnpj = $vreg[1];
		$vemail = $vreg[2];
		$vtelefone = $vreg[3];
		$vcod = $vreg[4];
		
		
		echo "<tr>";
		
		echo "<td>$vnome</td>";
		
		echo "<td>$vcnpj</td>";
		
		echo "<td>$vemail</td>";
		
		echo "<td>$vtelefone</td>";
		
		echo "<td>$vcod</td>";
	
		
		echo "<td align=center> <input type=checkbox value = $vcnpj name = sel[]></td>";
		
		echo "</tr>";
		
		
		
	}
	
	?>
    
    
    
    
   </table>
   <br />
   
   

   <input type="submit" class="button" value="Excluir" name="bt_excluir"/>
   </form>



</body>
</html>
</center></center>
</div>
