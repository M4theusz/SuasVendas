﻿<?php
$conn = mysqli_connect("mysql.hostinger.com.br","u806871350_venda","27210515","u806871350_rp");

?>