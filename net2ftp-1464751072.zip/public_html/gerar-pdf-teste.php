﻿<?php

include("pdf/mpdf.php");
include("conexao.php");



$cod="2";

$resultado = "SELECT *FROM produto WHERE cod='$cod'";

$resulado_final = mysqli_query($conn, $resultado);

$row_final = mysqli_fetch_array($resulado_final);

$pagina = 
	"<html>
	<body>
			<h1> Relatorio de produto</h1>
			cod: ".$row_final.['cod']."<br>
			produto: ".$row_final.['produto']."<br>
			caixa: ".$row_final.['caixa']."<br>
			descrição: ".$row_final.['descricao']."<br>
			valor: ".$row_final.['valor']."<br>
			peso: ".$row_final.['peso']."<br>
	
	</body>
	</html>
	";
	
	
	
	
	
	$arquivo = "cadastro01.pdf";
	
	$mpdf = new mPDF();
	
	$mpdf ->WriteHTML ("$pagina");
	
	$mpdf-> Output($arquivo, 'I');



?>