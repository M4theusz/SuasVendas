﻿
<div id='cssmenu' class="fixed-menu">

<ul>
   <li><a href='index1.php'>Home</a></li>
   
   
  		 <li class='active'><a href='#'>Fornecedores</a>
         		
      
  		 </li>
   
   
   <li><a href='#'>Produtos</a>
   
               
   </li>
   
   
   <li><a href='#'>Clientes</a>

         		
               
   </li>





</div>