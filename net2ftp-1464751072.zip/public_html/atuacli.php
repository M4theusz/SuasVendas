<?php include("autenticacao.php"); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>Atualizar Cadastro de Clientes - Formoid form css</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>




<!-- Start Formoid form-->
<link rel="stylesheet" href="atuacli_files/formoid1/formoid-metro-cyan.css" type="text/css" />
<script type="text/javascript" src="atuacli_files/formoid1/jquery.min.js"></script>

<form class="formoid-metro-cyan" style="background-color:#FFFFFF;font-size:14px;font-family:'Open Sans','Helvetica Neue','Helvetica',Arial,Verdana,sans-serif;color:#666666;max-width:480px;min-width:150px" method="post" action="query/confirma-atua-cli.php"><div class="title"><h2>Atualizar Cadastro de Clientes</h2></div>
	
    <div class="element-phone"><label class="title">Informe o CPF/CNPJ</label><input class="large" type="tel"  name="cpf"  /></div>


<div class="submit"><input type="submit" value="Submit"/></div></form><p class="frmd"><a href="http://formoid.com/v29.php">form css</a> Formoid.com 2.9</p><script type="text/javascript" src="atuacli_files/formoid1/formoid-metro-cyan.js"></script>
<!-- Stop Formoid form-->



</body>
</html>
