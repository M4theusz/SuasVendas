﻿<?php
// Inclui a conexão
include("conexao.php");

// Nome do Arquivo do Excel que será gerado
$arquivo = 'lista.produtos.xls';



// Criamos uma tabela HTML com o formato da planilha para excel
$tabela = '<table border="1">';
$tabela .= '<tr>';
$tabela .= '<td colspan="4"><b>Produtos<b></tr>';
$tabela .= '</tr>';
$tabela .= '<tr>';
$tabela .= '<td><b>Codigo</b></td>';
$tabela .= '<td><b>Produto</b></td>';
$tabela .= '<td><b>Caixa</b></td>';
$tabela .= '<td><b>Descrição</b></td>';
$tabela .= '<td><b>Valor</b></td>';
$tabela .= '<td><b>Peso</b></td>';
$tabela .= '<td><b>Codigo de Produto da Empresa</b></td>';

$tabela .= '</tr>';

// Puxando dados do Banco de dados
$resultado = mysqli_query($conn, "SELECT * FROM produto ")or die (mysqli_error());

while($dados = mysqli_fetch_array($resultado))
{
$tabela .= '<tr>';
$tabela .= '<td>'.$dados['cod'].'</td>';
$tabela .= '<td>'.$dados['produto'].'</td>';
$tabela .= '<td>'.$dados['caixa'].'</td>';
$tabela .= '<td>'.$dados['descricao'].'</td>';
$tabela .= '<td>'.$dados['valor'].'</td>';
$tabela .= '<td>'.$dados['peso'].'</td>';
$tabela .= '<td>'.$dados['cod_prod_empresa'].'</td>';
$tabela .= '</tr>';
}

$tabela .= '</table>';

// Força o Download do Arquivo Gerado
header ('Cache-Control: no-cache, must-revalidate');
header ('Pragma: no-cache');
header('Content-Type: application/x-msexcel');
header ("Content-Disposition: attachment; filename=\"{$arquivo}\"");
echo $tabela;
?>