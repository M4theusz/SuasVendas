﻿<?php
// Inclui a conexão
include("conexao.php");

// Nome do Arquivo do Excel que será gerado
$arquivo = 'lista.Clientes.xls';



// Criamos uma tabela HTML com o formato da planilha para excel
$tabela = '<table border="1">';
$tabela .= '<tr>';
$tabela .= '<td colspan="4"><b>Clientes<b></tr>';
$tabela .= '</tr>';
$tabela .= '<tr>';
$tabela .= '<td><b>Nome</b></td>';
$tabela .= '<td><b>Cpf/Cnpj</b></td>';
$tabela .= '<td><b>Nome Fantasia</b></td>';
$tabela .= '<td><b>Telefone</b></td>';
$tabela .= '<td><b>E-mail</b></td>';

$tabela .= '</tr>';

// Puxando dados do Banco de dados
$resultado = mysqli_query($conn, "SELECT * FROM clientes")or die (mysqli_error());

while($dados = mysqli_fetch_array($resultado))
{
$tabela .= '<tr>';
$tabela .= '<td>'.$dados['nome'].'</td>';
$tabela .= '<td>'.$dados['cpf_cnpj'].'</td>';
$tabela .= '<td>'.$dados['nome_fantasia'].'</td>';
$tabela .= '<td>'.$dados['telefone'].'</td>';
$tabela .= '<td>'.$dados['email'].'</td>';

$tabela .= '</tr>';
}

$tabela .= '</table>';

// Força o Download do Arquivo Gerado
header ('Cache-Control: no-cache, must-revalidate');
header ('Pragma: no-cache');
header('Content-Type: application/x-msexcel');
header ("Content-Disposition: attachment; filename=\"{$arquivo}\"");
echo $tabela;
?>