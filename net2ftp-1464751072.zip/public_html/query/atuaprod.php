﻿<?php 
include "../conexao.php";

if($_POST)
$codigo= $_POST['codigo'];
$produto= $_POST['produto'];
$caixa = $_POST['caixa'];
$descricao = $_POST['descricao'];
$valor = $_POST['valor'];
$peso = $_POST['peso'];
$cod = $_POST['cod'];





$sql= "UPDATE produto SET produto = '$produto' , caixa='$caixa' , descricao = '$descricao' ,peso = '$peso' , cod_prod_empresa='$cod' WHERE cod = '$codigo'";
 
$res= mysqli_query($conn, $sql) or die (mysqli_error());

if($res)
{

header("location=../index1.php ");
echo"<center>Sucesso</center>";
} 
else
{
echo"<center>Fail</center>";
header("location=../atualizarforn.php ");

}


?>
