﻿<?php

include "../conexao.php";

if($_POST)

$cnpj = $_POST['cnpj'];



$res = mysqli_query($conn, "SELECT *FROM fornecedores WHERE cnpj = '$cnpj'")or die (mysql_error());
$row = mysqli_num_rows($res);
if($row > 0)
{
	echo"Fornecedor encontrado";
	header("location:../atualizarforn.php");
}
else
{
	echo"Fornecedor não encontrado";
	header("location:../conf-atua-forn.php");
	
}



?>


