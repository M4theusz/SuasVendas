﻿
<?php include "../conexao.php";

if($_POST)

$nome = $_POST['nome'];
$cnpj = $_POST['cnpj'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$nomefantasia = $_POST['fantasia'];





$sql= "UPDATE clientes SET nome = '$nome' , email='$email' , telefone = '$telefone' , nome_fantasia='$nomefantasia' WHERE cpf_cnpj = '$cnpj'";
 
$res= mysqli_query($conn, $sql) or die (mysqli_error());

if($res)
{
	
echo"<center><h1>Sucesso</h1></center>";

 
header('Location = ../listadeclientes.php');

} 
else
{
echo"<center><h1>Erro</h1></center>";

header("location = ../atualizarforn.php ");

}
 
?>
