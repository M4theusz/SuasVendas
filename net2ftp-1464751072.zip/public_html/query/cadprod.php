﻿<?php  
if($_POST)
{
	
$produto = $_POST['produto'];
$caixa = $_POST['caixa'];
$descricao = $_POST['descricao'];
$valor = $_POST['valor'];
$peso = $_POST['peso'];
$cod_prod_empresa = $_POST['cod_prod_empresa'];


$query = "INSERT INTO produto(";
$query = $query . "produto,";
$query = $query . "caixa,";
$query = $query . "descricao,";
$query = $query . "valor,";
$query = $query . "peso,";
$query = $query . "cod_prod_empresa)";


$query = $query . "VALUES(";
$query = $query . "'$produto',";
$query = $query . "'$caixa',";
$query = $query . "'$descricao',";
$query = $query . "'$valor',";
$query = $query . "'$peso',";
$query = $query . "'$cod_prod_empresa')";
mysqli_query($conn,$query) or die(mysql_error());
}


?>