﻿<?php include("cabecalho1.php"); ?>
<div id="topo">
<img src="img/topo.jpg" width="1498" height="135">
</div>
<?php include("menu.php"); ?>
<div id="fundo">
<br />
<br />
<br />
<?php include("form-atualizacao-senha.php"); ?>
</div>
<?php include("rodape.php"); ?>

</body>
</html>