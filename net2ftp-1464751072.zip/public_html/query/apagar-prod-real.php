﻿<?php
include("../conexao.php");
header("location:../listadeprodutos.php");
$cod = $_REQUEST['id'];
$query = "DELETE FROM produto WHERE cod = $cod";
mysqli_query ($conn,$query);


?>