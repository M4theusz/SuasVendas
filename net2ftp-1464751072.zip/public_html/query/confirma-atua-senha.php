﻿<?php

include "../conexao.php";

if($_POST)

$email = $_POST['email'];



$res = mysqli_query($conn, "SELECT *FROM cadastro WHERE email = '$email'")or die (mysql_error());
$row = mysqli_num_rows($res);
if($row > 0)
{
	echo"Cadastro encontrado";
	header("location:../form-atualizacao-senha2.php");
}
else
{
	header("location:../conf-email.php");
	
}



?>

