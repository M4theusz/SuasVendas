﻿<?php

	

$selecao = mysqli_query($conn,"SELECT * FROM fornecedores");

echo "<table  cellspacing=\"17\" align=\"center\" cellpadding=\"6px\" border=\"1\" width=\"851px\" >";

echo"<td><b>Nome da Empresa</b></td>";

echo"<td><b>CNPJ</b></td>";

echo"<td><b>E-mail</b></td>";

echo"<td><b>Telefone</b></td>";

echo"<td><b>Codigo de Produto da Empresa</b></td>";


while($linha = mysqli_fetch_assoc($selecao))
{
	
	echo"<tr>";
	
echo  "<td>". $linha["nomedaempresa"]."</td>";
echo  "<td>".$linha["cnpj"]."</td>";
echo  "<td>".$linha["email"]."</td>";
echo  "<td>".$linha["telefone"]."</td>";
echo  "<td>".$linha["cod_prod_empresa"]."</td>";
 
 echo"</tr>";
 
 }
echo"</table>\n";
?>