﻿<?php
include("../conexao.php");
header("location:../listadefornecedores.php");
$idcnpj = $_REQUEST['id'];
$query = "DELETE FROM fornecedores WHERE cnpj=$idcnpj";
mysqli_query ($conn,$query);


?>