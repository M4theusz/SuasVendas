﻿
<?php

include "../conexao.php";

if($_POST)

$cpf = $_POST['cpf'];


$query="SELECT *FROM clientes WHERE cpf_cnpj = '$cpf'";


$res = mysqli_query($conn, $query)or die (mysql_error());
$row = mysqli_num_rows($res);
if($row > 0)
{
	
	header("location:../atualizarcli.php");
}
else
{
	
	header("location:../conf-atua-cli.php");
	
}



?>





