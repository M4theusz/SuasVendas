﻿
<?php

if($_POST)
{

$nome = $_POST['nome_da_empresa'];
$cpf = $_POST['cpfcpnj'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$cod = $_POST['cod_da_empresa'];



$query = "INSERT INTO fornecedores(";
$query = $query . "nomedaempresa,";
$query = $query . "cnpj,";
$query = $query . "email,";
$query = $query . "telefone,";
$query = $query . "cod_prod_empresa)";


$query = $query . "VALUES(";
$query = $query . "'$nome',";
$query = $query . "'$cpf',";
$query = $query . "'$email',";
$query = $query . "'$telefone',";
$query = $query . "'$cod')";

mysqli_query($conn,$query) or die(mysql_error());
}
?>