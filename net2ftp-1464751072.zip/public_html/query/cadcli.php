﻿<?php
include("../conexao.php");
header("location:../listadeclientes.php");
if($_POST)
{ 


	
	
$nome = $_POST['nome'];
$cpf = $_POST['cpfcpnj'];
$fantasia = $_POST['nome_fantasia'];
$tel = $_POST['telefone'];
$mail = $_POST['email'];



$query = "INSERT INTO clientes(";
$query = $query . "nome,";
$query = $query . "cpf_cnpj,";
$query = $query . "nome_fantasia,";
$query = $query . "telefone,";
$query = $query . "email)";

$query = $query . "VALUES(";
$query = $query . "'$nome',";
$query = $query . "'$cpf',";
$query = $query . "'$fantasia',";
$query = $query . "'$tel',";
$query = $query . "'$mail')";
mysqli_query($conn, $query) or die(mysqli_error());
}

header("location:../listadeclientes.php");

?>
