﻿<?php

	

$selecao = mysqli_query($conn,"SELECT * FROM clientes");



echo "<table  cellspacing=\"17\" align=\"right\" cellpadding=\"6px\" border=\"1\" width=\"851px\" >";

echo"<td><b>Nome</b></td>";

echo"<td><b>CPF/CNPJ</b></td>";

echo"<td><b>Nome Fantasia</b></td>";

echo"<td><b>Telefone</b></td>";

echo"<td><b>Email</b></td>";

while($linha = mysqli_fetch_assoc($selecao))
{

	echo"<tr>";
	
	echo "<td>".$linha["nome"]."</td>";
	echo "<td>".$linha["cpf_cnpj"]."</td>";
	echo "<td>".$linha["nome_fantasia"]."</td>";
 	echo "<td>".$linha["telefone"]."</td>";
 	echo "<td>".$linha["email"]."</td>";
 	
	echo"</tr>";
}
echo"</table>\n";
?>