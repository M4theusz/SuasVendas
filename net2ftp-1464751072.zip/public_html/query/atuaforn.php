﻿<?php 
include "../conexao.php";
header("location=../index1.php ");
if($_POST)

$nome = $_POST['nome'];
$cnpj = $_POST['cnpj'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$cod = $_POST['cod'];





$sql= "UPDATE fornecedores SET nomedaempresa = '$nome' , email='$email' , telefone = '$telefone' , cod_prod_empresa='$cod' WHERE cnpj = '$cnpj'";
 
$res= mysqli_query($conn, $sql) or die (mysqli_error());

if($res)
{

header("location=../index1.php ");
echo"<center>Sucesso</center>";
} 
else
{
echo"<center>Fail</center>";
header("location=../atualizarforn.php ");

}


?>
