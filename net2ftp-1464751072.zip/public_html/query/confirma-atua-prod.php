﻿<?php

include "../conexao.php";
$row = mysqli_num_rows($res);
if($_POST)

$cod = $_POST['cod'];



$res = mysqli_query($conn, "SELECT *FROM produto WHERE cod = '$cod'")or die (mysql_error());
$row = mysqli_num_rows($res);
if($row > 0)
{
	echo"Produto encontrado";
	header("location:../atualizarprod.php");
}
else
{
	echo"Cliente não encontrado";
	header("location:../conf-atua-prod.php");
	
}



?>



