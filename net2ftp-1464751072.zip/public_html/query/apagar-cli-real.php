﻿<?php
include("../conexao.php");
header("location:../listadeclientes.php");
$idcnpj = $_REQUEST['id'];
$query = "DELETE FROM clientes WHERE cpf_cnpj=$idcnpj";
mysqli_query ($conn,$query);


?>