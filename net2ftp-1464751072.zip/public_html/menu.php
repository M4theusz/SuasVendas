<?php include("conexao.php"); ?>

<div id='cssmenu' class="fixed-menu">

<ul>
   <li><a href='index1.php'>Home</a></li>
   
   
  		 <li class='active'><a href='#'>Fornecedores</a>
      		<ul>
            
			
                 <?php
             			if(strpos($_SESSION['acesso'],'i',0))
				
					echo"<li><a href='cadastrodefornecedores.php'>Cadastro</a>";
				?>
        			<li><a href='listadefornecedores.php'>Lista de Fornecedores</a>
				
				
				<?php
                
				if(strpos($_SESSION['acesso'],'u',0))
				{
					echo"<li><a href='conf-atua-forn.php'>Atualizar</a>";
				}
           	 ?>
              
            </ul>
         		</li>
      
  		 </li>
   
   
   <li><a href='#'>Produtos</a>
   
  			 <ul>
             <?php
             		if(strpos($_SESSION['acesso'],'i',0))
        		echo"<li><a href='cadastrodeprodutos.php'>Cadastro</a>";
			  ?>
              
              
              
        		<li><a href='listadeprodutos.php'>Lista de Produtos</a>
         		
            	
                <?php
                
				if(strpos($_SESSION['acesso'],'u',0))
				{
               		echo"<li><a href='conf-atua-prod.php'>Atualizar</a>";
				}
				?>
            </ul>
         		
               </li>
   </li>
   
   
   <li><a href='#'>Clientes</a>
		 <ul>
          <?php
             	if(strpos($_SESSION['acesso'],'i',0))
					{
        				echo"<li><a href='cadastroclientes.php'>Cadastro</a>";
					}
		  ?>			
        		<li><a href='listadeclientes.php'>Lista de Clientes</a>
         		
                
                <?php
                	if(strpos($_SESSION['acesso'],'u',0))
						{
            				echo"<li><a href='conf-atua-cli.php'>Atualizar</a>";
						}
             	?> 
        </ul>
         		
               </li>
   </li>

<li><a href='logout.php'>Sair</a></li>

</ul>

</div>