﻿<?php
if($_POST){


	

$codigo = $_POST['cod'];
$selecao = mysqli_query($conn,"DELETE  FROM produto WHERE cod=$codigo");

}
?>