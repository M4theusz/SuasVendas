<html>
<head>

<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="css/ediform.css">

<link rel="stylesheet" type="text/css" href="css/edimenu.css">

<link rel="stylesheet" type="text/css" href="css/formatacao.css">

<link rel="shortcut icon" href="img/favicon.jpg" type="image/x-icon"/>

<link rel="stylesheet" href="css/reset.css">

<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>

<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

<link rel="stylesheet" href="css/style.css">



<title> SuasVendas.com</title>

</head>
