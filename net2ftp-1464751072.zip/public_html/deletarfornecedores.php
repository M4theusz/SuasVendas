﻿<?php include("cabecalho.php"); ?>
<?php include("menu.php"); ?>
<?php include("conexao.php");?>
<?php include("delforn.php");?>



<div id="conteudo">
<div id="conteudotitulo"><br > 
Deletar Fornecedores
</div>
<br > 


<center>
<form id="contactform" class="rounded"method="post" action="deletarfornecedores.php">
				
				<br>
				<br>
				<label ="cnpj">Digite o CNPJ do Fornecedor cadastrado:</label>
                
		<input type="number" name="cnpj" placeholder="NÃO DIGITE SIMBOLOS " size="40" /><br>
			
            <input type="submit" class="button" value="Enviar" /> 
		</form>
        </center>
</div>

<?php include("rodape.php"); ?>	