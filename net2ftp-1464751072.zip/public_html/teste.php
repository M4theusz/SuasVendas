﻿<?php
// Inclui a conexão
$conect = mysqli_connect("localhost","root","root","representante_comercial");
if(!$conect) die ("<h1> Falha na coneção</h1>");



// Nome do Arquivo do Excel que será gerado
$arquivo = 'produtos.xls';

// Criamos uma tabela HTML com o formato da planilha para excel
$tabela = '<table border="1">';
$tabela .= '<tr>';
$tabela .= '<td colspan="2">Produtos</tr>';
$tabela .= '</tr>';
$tabela .= '<tr>';
$tabela .= '<td><b>Codigo</b></td>';
$tabela .= '<td><b>Produto</b></td>';
$tabela .= '<td><b>Caixa</b></td>';
$tabela .= '<td><b>Descrição</b></td>';
$tabela .= '<td><b>Valor</b></td>';
$tabela .= '<td><b>Peso</b></td>';
$tabela .= '<td><b>cod_prod_empresa</b></td>';
$tabela .= '</tr>';





if($_POST)
{
$nome= $_POST['nome'];
$empresa= $_POST['empresa'];
$nome= $_POST['nome'];
}




// Puxando dados do Banco de dados
$resultado = mysqli_query($conect,"SELECT 
	  FROM clientes.nome,fornecedores.nomedaempresa,produto.cod_prod_empresa 
	  WHERE clientes.nome = $nome ,fornecedores.nomedaempresa = $empresa, fornecedores.cnpj = produto.cod_prod_empresa");

while($dados = mysqli_fetch_assoc($conect,$resultado))
{
$tabela .= '<tr>';
$tabela .= '<td>'.$dados['nome'].'</td>';
$tabela .= '<td>'.$dados['nomedaempresa'].'</td>';
$tabela .= '<td>'.$dados['produto'].'</td>';
$tabela .= '</tr>';
}

$tabela .= '</table>';

// Força o Download do Arquivo Gerado
header ('Cache-Control: no-cache, must-revalidate');
header ('Pragma: no-cache');
header('Content-Type: application/x-msexcel');
header ("Content-Disposition: attachment; filename=\"{$arquivo}\"");
echo $tabela;
?>