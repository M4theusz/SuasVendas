<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>Atualizaçao de Clientes - Formoid form css</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>




<!-- Start Formoid form-->
<link rel="stylesheet" href="form-atualização-cli_files/formoid1/formoid-metro-cyan.css" type="text/css" />
<script type="text/javascript" src="form-atualização-cli_files/formoid1/jquery.min.js"></script>
<form class="formoid-metro-cyan" style="background-color:#FFFFFF;font-size:14px;font-family:'Open Sans','Helvetica Neue','Helvetica',Arial,Verdana,sans-serif;color:#666666;max-width:480px;min-width:150px" method="post" action="query/atuacli.php"><div class="title"><h2>Atualizaçao de Clientes</h2></div>
	
    <div class="element-input"><label class="title">Nome</label><input class="large" type="text" name="nome" /></div>
	
    <div class="element-phone"><label class="title">CPF<span class="required">*</span></label><input class="large" type="tel"  name="cnpj" required value=""/></div>
	
    <div class="element-email"><label class="title">Email</label><input class="large" type="email" name="email" value="" /></div>
	
    <div class="element-phone"><label class="title">Telefone</label><input class="large" type="tel" pattern="[+]?[\.\s\-\(\)\*\#0-9]{3,}" maxlength="24" name="telefone"  value=""/></div>
	
    <div class="element-input"><label class="title">Nome Fantasia</label><input class="large" type="text" name="fantasia" /></div>

<div class="submit"><input type="submit" value="Atualizar"/></div></form><p class="frmd"><a href="http://formoid.com/v29.php">form css</a> Formoid.com 2.9</p><script type="text/javascript" src="form-atualização-cli_files/formoid1/formoid-metro-cyan.js"></script>
<!-- Stop Formoid form-->



</body>
</html>
