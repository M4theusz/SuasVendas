﻿<?php


$selecao = mysqli_query($conn,"SELECT * FROM produto");

echo "<table  cellspacing=\"24\" align=\"right\" cellpadding=\"8px\" border=\"1\" width=\"851px\" >";

echo"<td><b>Codigo</b></td>";

echo"<td><b>Produto</b></td>";

echo"<td><b>Caixa</b></td>";

echo"<td><b>Descrição</b></td>";

echo"<td><b>Valor</b></td>";

echo"<td><b>Peso</b></td>";

echo"<td><b>Codigo de Produto da Empresa</b></td>";

while($linha = mysqli_fetch_assoc($selecao))
{
	echo"<tr>";

echo "<td>". $linha["cod"]."</td>";	
echo "<td>". $linha["produto"]."</td>";
echo "<td>".$linha["caixa"]."</td>";
echo "<td>".$linha["descricao"]."</td>";
echo "<td>".$linha["valor"]."</td>";
echo "<td>".$linha["peso"]."</td>";
echo "<td>".$linha["cod_prod_empresa"]."</td>";

	echo"</tr>";
 
 }
echo"</table>\n";
?>