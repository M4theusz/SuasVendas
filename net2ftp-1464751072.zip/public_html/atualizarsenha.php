﻿<?php 
include "conexao.php";


if($_POST)

$email = $_POST['email'];
$senhaantiga = $_POST['senha'];
$senhanova=$_POST['senha2'];


$consulta = "SELECT * FROM cadastro WHERE email = '$email' and senha = '$senhaantiga' ";

$resultado = mysqli_query($conn, $consulta) or die (mysqli_error());


$row = mysqli_num_rows($resultado);
if($row>0)
{
	$consulta = "UPDATE  cadastro SET senha = '$senhanova' WHERE email = '$email'";
	$resultado = mysqli_query($conn, $consulta) or die (mysqli_error());
	echo"Atualizado com sucesso";
	header("location:index.php");
}
else
{
echo"Senha Antiga Errada";	
header("location:form-atualizacao-senha2.php");
}



?>