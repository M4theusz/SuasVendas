﻿<html>
<head>
<link rel="stylesheet" type="text/css" href="css/formatacao.css">
<link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
</head>
</html>
<?php include("conexao.php");?>
<?php
session_start();

echo"<div id='h3'>Bem Vindo $_SESSION[usuario]</div>";


if(!isset($_SESSION["usuario"]) || !isset($_SESSION["senha"]))
{
header("Location: index.php");
exit;
}else
{

}
?>
