<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>Atualização de Produto - Formoid html5 form</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>




<!-- Start Formoid form-->
<link rel="stylesheet" href="form-atualização-prod_files/formoid1/formoid-metro-cyan.css" type="text/css" />
<script type="text/javascript" src="form-atualização-prod_files/formoid1/jquery.min.js"></script>
<form class="formoid-metro-cyan" style="background-color:#ffffff;font-size:14px;font-family:'Open Sans','Helvetica Neue','Helvetica',Arial,Verdana,sans-serif;color:#666666;max-width:480px;min-width:150px" method="post" action="query/confirma-atua-prod.php"><div class="title"><h2>Atualização de Produto</h2></div>
	
    <div class="element-phone"><label class="title">Digite o Código do Produto</label><input class="large" type="tel" name="cod"  value=""/></div>


<div class="submit"><input type="submit" value="Enviar"/></div></form><p class="frmd"><a href="http://formoid.com/v29.php">html5 form</a> Formoid.com 2.9</p><script type="text/javascript" src="form-atualização-prod_files/formoid1/formoid-metro-cyan.js"></script>
<!-- Stop Formoid form-->



</body>
</html>
