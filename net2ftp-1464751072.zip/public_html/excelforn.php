﻿<?php
// Inclui a conexão
include("conexao.php");

// Nome do Arquivo do Excel que será gerado
$arquivo = 'lista.fornecedores.xls';



// Criamos uma tabela HTML com o formato da planilha para excel
$tabela = '<table border="1">';
$tabela .= '<tr>';
$tabela .= '<td colspan="4"><b>Fornecedores<b></tr>';
$tabela .= '</tr>';
$tabela .= '<tr>';
$tabela .= '<td><b>Nome da Empresa</b></td>';
$tabela .= '<td><b>Cnpj</b></td>';
$tabela .= '<td><b>E-mail</b></td>';
$tabela .= '<td><b>Telefone</b></td>';
$tabela .= '<td><b>Codigo de Produto da Empresa</b></td>';

$tabela .= '</tr>';

// Puxando dados do Banco de dados
$resultado = mysqli_query($conn, "SELECT * FROM fornecedores")or die (mysqli_error());

while($dados = mysqli_fetch_assoc($resultado))
{
$tabela .= '<tr>';
$tabela .= '<td>'.$dados['nomedaempresa'].'</td>';
$tabela .= '<td>'.$dados['cnpj'].'</td>';
$tabela .= '<td>'.$dados['email'].'</td>';
$tabela .= '<td>'.$dados['telefone'].'</td>';
$tabela .= '<td>'.$dados['cod_prod_empresa'].'</td>';

$tabela .= '</tr>';
}

$tabela .= '</table>';

// Força o Download do Arquivo Gerado
header ('Cache-Control: no-cache, must-revalidate');
header ('Pragma: no-cache');
header('Content-Type: application/x-msexcel');
header ("Content-Disposition: attachment; filename=\"{$arquivo}\"");
echo $tabela;
?>