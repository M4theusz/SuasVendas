
<?php include("cabecalho.php"); ?>
<?php include("menu.php"); ?>
    
        

        <title>Pedidos</title>
        
<div id="conteudo">

<div id="titulo">
<br>
Pedidos
</div>

<br >
				<form method="post" action="teste.php">
				
				<br>
				<br>
                
				<b>nome do cliente:</b><br>
		<input type="text" name="nome" placeholder="Cpf/CNPJ" size="45"><br>
				
				<b>nome da empresa:</b><br>
		<input type="text" name="empresa" size="45"><br>
				
				<b>Codigo do Produto:</b><br>
		<input type="number" name="cod" size="45"><br>
		
		
		<input type="submit" value="Enviar" <input type="reset" value="Limpar Formulário">
		</form>
			
			<br>
            <br>
            <br> <a href="teste.php">Relatorio</a>
                </div>
                
<?php include("rodape.php"); ?>	
		
			
