﻿<?php include("autenticacao.php"); ?>
<?php include("cabecalho1.php"); ?>


<?php include("menu.php"); ?>

<div id="conteudo">
<?php include("conexao.php");?>
<b>Lista de Produtos em Excel Clique --></b><a href="excelprod.php"><img src="img/excel.png" width="30" height="30"/></a>
	<div id="conteudotitulo">
    Lista de Produtos
    </div>

<br />

<center>

<?php include("lista-del-prod.php");?>
</div>

<?php include("rodape.php"); ?>	