﻿<?php include("conexao.php");?>

<html>
<head>

<title>Autenticando aguarde um instante</title>



<script type="text/javascript">

		function loginsuccessfully()
			{
	
				setTimeout("window.location='index1.php'",3000);	
			}
		function loginfailed()
			{
	
				setTimeout("window.location='index.php'",3000);		
			}


</script>


		<link rel="stylesheet" href="css/style1.css" media="screen"/>


<script src="js/jquery-2.1.3.js">

</script>


</head>
<body>
<?php 
session_start();
$usuario= $_POST['usuario'];
$acesso= $_POST['acesso'];
$senha= $_POST['senha'];

$sql = mysqli_query($conn, "SELECT usuario,senha,acesso
						    FROM cadastro 
							WHERE usuario = '$usuario' and senha = MD5('$senha')and acesso ='$acesso' ") or die(mysql_error());

$row = mysqli_num_rows($sql);

	if($row > 0)
		{
			
			
			$_SESSION['acesso']=$_POST['acesso'];
			$_SESSION['usuario']=$_POST['usuario'];
			$_SESSION['senha']=$_POST['senha'];
			$_SESSION['logou']="S";
	
	
	
	echo "<div id='loader'>
		
	<script>loginsuccessfully()</script>
	
		
					<script type='text/javascript'>
					
// Este evendo é acionado após o carregamento da página
		
					jQuery(window).load(function() 
					
					{
			
//Após a leitura da pagina o evento fadeOut do loader é acionado, esta com delay para ser perceptivo em ambiente fora do servidor.
			
						jQuery('#loader').delay(2000).fadeOut('slow');
						
						
					}
					
		</div>";
	
}
else
{
	include("cabecalho1.php"); 
 	include("conexao.php");
 	include("menufalso.php"); 

	
	echo"<div id='fundo'>
	
<h1>
	<center>
	<br>
	<br>
	<br>
		Nome de usuario ou Senha invalidos
	</center>
</h1>

		</div>";
		
echo "<script>loginfailed()</script>";	


include("rodape.php"); 	
}

?>


</body>
</html>