﻿<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/formatacao.css">
<title>Documento sem título</title>
</head>

<body>


		<form name="f_excluir" method="post" action="listadeprodutos.php">

				<table cellspacing="20"  cellpadding="100px" border="1" width="950" id="table">
    
  					  <tr>
    					
                        <td><b>Codigo</b></td> 
        				<td><b>Produto</b></td> 
       					<td><b>Caixa</b></td>
						<td><b>Descrição</b></td> 
        				<td><b>Valor</b></td>
                        <td><b>Peso</b></td>
                        <td><b>Codigo de Produto da Empresa</b></td>
        				<td><b>APAGAR</b></td>
    				
                     </tr>
    
    <?php 
	include("conexao.php");
	
	$sql= "SELECT * FROM produto ";
	$res=mysqli_query($conn,$sql);
	
	while($linha=mysqli_fetch_assoc($res))
	{
	echo "<tr>";
		
	echo "<td>".$linha['cod']."</td>";
	echo "<td>".$linha['produto']."</td>";
	echo "<td>".$linha['caixa']."</td>";
	echo "<td>".$linha['descricao']."</td>";
	echo "<td>".$linha['valor']."</td>";
	echo "<td>".$linha['peso']."</td>";
	echo "<td>".$linha['cod_prod_empresa']."</td>";
	if(strpos($_SESSION['acesso'],'d',0))
	{
	echo "<td><a href='apagarprod.php?id=".$linha['cod']."'><img src='img/botao.png' width='30'></a></td>";
	}
	echo "</tr>";
		
		
		
	}
	
	?>
    
    
    
    
   </table>
   <br />
   
   


   </form>



</body>
</html>
</center></center>
</div>
