﻿<?php
if($_POST){


$cliente = $_POST['cpf'];
$selecao = mysqli_query($conn,"DELETE  FROM clientes WHERE cpf_cnpj=$cliente");

}
?>