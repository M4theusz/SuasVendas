﻿<?php include("cabecalho.php"); ?>
<?php include("menu.php"); ?>


<div id="conteudo">
<div id="titulo">
<br>
Produtos
</div>

<br>
<br>
<br>

&nbsp;&nbsp;&nbsp;&nbsp;<a href="cadastrodeprodutos.php"><b>*</b>Cadastro de Produtos</a>
<br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="listadeprodutos.php"><b>*</b>Lista de Produtos Cadastrados</a>
<br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="deletarprodutos.php"><b>*</b>Apagar Produtos Cadastrados</a>
<br>

</div>



<?php include("rodape.php"); ?>	