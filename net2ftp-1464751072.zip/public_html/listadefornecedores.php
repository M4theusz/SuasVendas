﻿<?php include("autenticacao.php"); ?>
<?php include("cabecalho1.php"); ?>

<?php include("menu.php"); ?>
<div id="conteudo">
<?php include("conexao.php");?>
<b>Lista de Fornecedores em Excel Clique --></b><a href="excelforn.php"><img src="img/excel.png" width="30" height="30"/></a>
	<div id="conteudotitulo">
    Lista de Fornecedores
    </div>

<br />

<center>


<center>
<?php include("lista-del-forn.php");?>
</center>

</div>


<?php include("rodape.php"); ?>	