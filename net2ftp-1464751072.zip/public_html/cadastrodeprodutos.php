﻿<?php include("autenticacao.php"); ?>
<?php include("cabecalho1.php"); ?>



<?php include("menu.php"); ?>
<div id="fundo">
<?php include("conexao.php");?>
<?php include("query/cadprod.php");?>
<br>
<br>
<br>
<?php include("form1.php"); ?>	
</div>
<?php include("rodape.php"); ?>	