﻿<?php include("cabecalho.php"); ?>
<?php include("menu.php"); ?> 
<div id="conteudo">
<div id="sucesso">
<br>

Enviado com Sucesso!!
<br>
<br>
<br>

</div>
<a href="cadastrodefornecedores.php">Voltar</a>
</div>
<?php include("rodape.php"); ?>	