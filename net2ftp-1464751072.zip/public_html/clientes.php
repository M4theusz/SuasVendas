﻿<?php include("cabecalho.php"); ?>
<?php include("menu.php"); ?>



<div id="conteudo">

<div id="titulo">
<br>
Clientes
</div>

<br>
<br>
<br>

&nbsp;&nbsp;&nbsp;&nbsp;<a href="cadastroclientes.php"><b>*</b>Cadastro de Clientes</a>
<br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="listadeclientes.php"><b>*</b>Lista de Clientes Cadastrados</a>
<br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="deletarclientes.php"><b>*</b>Apagar Clientes Cadastrados</a>
<br>

</div>


<?php include("rodape.php"); ?>	