﻿<?php include("autenticacao.php"); ?>
<?php include("cabecalho1.php");?>



<?php 
      include("conexao.php"); 
include("menu.php");
print "<div id='conteudo'>";

 $cod = $_REQUEST['id'];
 
	print"<div id='apagar'>";

 print "Tem certeza que deseja apagar o Produto de Codigo =<b> $cod</b>.<br><br>"; 

 print "Confirma?<br><br>";

 print "<a href='query/apagar-prod-real.php?id=$cod'><img src='img/sim.png' height='49' width='49'></a>";

 print "&nbsp;&nbsp;&nbsp;&nbsp;";

 print "<a href='listadeprodutos.php'><img src='img/nao.png'></a>";
		print "</div> </div>";
		
 include("rodape.php");

?>